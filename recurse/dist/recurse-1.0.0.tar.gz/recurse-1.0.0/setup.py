from distutils.core import setup

setup (
        name            = 'recurse',
        version         = '1.0.0',
        py_modules      = ['recurse'],
        description     = ' a simple printer of nested lists'
      )
